#ifndef SCORE_H_INCLUDED
#define SCORE_H_INCLUDED

class Score{
public:
    Score() { score = 0; }

    int score;
};

#endif // SCORE_H_INCLUDED
