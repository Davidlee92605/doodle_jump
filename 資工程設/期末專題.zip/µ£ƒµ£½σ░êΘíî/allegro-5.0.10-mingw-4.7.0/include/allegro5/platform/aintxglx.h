#ifndef __al_included_allegro5_aintxglx_h
#define __al_included_allegro5_aintxglx_h

ALLEGRO_DISPLAY_INTERFACE *_al_display_xglx_driver(void);
ALLEGRO_SYSTEM_INTERFACE *_al_system_xglx_driver(void);

#endif
